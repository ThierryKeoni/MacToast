//
//  ContentView.swift
//  MacToast
//
//  Created by Thierry Keoni on 20/03/2026.
//

import SwiftUI
import AppKit
import Combine
import UserNotifications

// ─────────────────────────────────────────────────────────────────────────────
// MacShot — ContentView.swift
// Minimum: macOS 11.0 Big Sur
// Universal: arm64 (Apple Silicon) + x86_64 (Intel)
// ─────────────────────────────────────────────────────────────────────────────

// MARK: - ErrorGeneratorTab

private func showSystemError(customTitle: String, errorMessage: String, errorImageName: String) {
    let window = NSWindow(
        contentRect: NSRect(x: 0, y: 0, width: 420, height: 160),
        styleMask: [.titled, .fullSizeContentView],
        backing: .buffered, defer: false)
    
    window.center()
    window.title = ""
    window.titlebarAppearsTransparent = true
    window.isReleasedWhenClosed = false
    
    window.contentView = NSHostingView(rootView: FakeAlertView(
        title: customTitle,
        message: errorMessage,
        iconName: errorImageName,
        onClose: { window.close() }
    ))
    
    window.makeKeyAndOrderFront(nil)
    NSApp.activate(ignoringOtherApps: true)
}


// FakeAlertView - Disables the badge beside the icon.

struct FakeAlertView: View {
    let title: String
    let message: String
    let iconName: String // "stop", "caution", "note"
    var onClose: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            // THE PURE ICON
            Group {
                if iconName == "stop" {
                    Image(nsImage: NSImage(named: "NSStopProgressFreestanding") ?? NSImage())
                } else if iconName == "caution" {
                    Image(nsImage: NSImage(named: "NSCaution") ?? NSImage())
                } else {
                    Image(nsImage: NSImage(named: "NSInfo") ?? NSImage())
                }
            }
            .frame(width: 64, height: 64)

            VStack(alignment: .leading, spacing: 8) {
                Text(title).font(.headline)
                Text(message).font(.subheadline).foregroundColor(.primary)
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button("OK") { onClose() }
                        .keyboardShortcut(.defaultAction)
                        .controlSize(.large)
                }
            }
        }
        .padding(20)
        .frame(width: 420, height: 160)
        .background(VisualEffectView().ignoresSafeArea()) // Classic blurred background
    }
}

// Helper for the blurred Mac look
struct VisualEffectView: NSViewRepresentable {
    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        view.material = .sidebar
        view.blendingMode = .behindWindow
        view.state = .active
        return view
    }
    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {}
}

// MARK: - Window Info

struct WindowInfo: Identifiable, Hashable {
    let id: Int
    let name: String
    let ownerName: String
    let pid: pid_t

    var displayName: String {
        ownerName + (name.isEmpty ? "" : " – \(name)")
    }
}

// MARK: - Scriptrunner Tab


struct TerminalErrorsTab: View {
    @State private var folderURL: URL?
    @State private var commandFiles: [URL] = []
    @State private var selectedCommand: URL?
    @State private var showingCreator = false

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Button(action: { showingCreator = true }) {
                HStack {
                    Image(systemName: "plus.square.fill")
                    Text("Create Error CMD")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(FilledButton(color: .blue))
            
            CardBox {
                SectionLabel(text: "Terminal Library")
                HStack(spacing: 10) {
                    Image(systemName: folderURL != nil ? "terminal.fill" : "folder.badge.questionmark")
                        .foregroundColor(.secondary)
                    Text(folderURL?.lastPathComponent ?? "Searching Desktop...")
                        .font(.system(size: 11, design: .monospaced))
                    Spacer()
                    if folderURL != nil {
                        Button { loadCommands(from: folderURL!) } label: {
                            Image(systemName: "arrow.clockwise").font(.system(size: 12, weight: .bold))
                        }
                        .buttonStyle(.borderless)
                    }
                    Button("Change") { selectFolder() }.buttonStyle(.borderless)
                }
                .padding(8)
                .background(Color.black.opacity(0.05).cornerRadius(6))
            }

            CardBox {
                SectionLabel(text: "Available Commands (.sh)")
                VStack {
                    if commandFiles.isEmpty {
                        Spacer()
                        Text("No shell scripts found.").font(.system(size: 11)).foregroundColor(.secondary)
                        Spacer()
                    } else {
                        ScrollView {
                            VStack(spacing: 2) {
                                ForEach(commandFiles, id: \.self) { file in
                                    HStack {
                                        Image(systemName: "chevron.right.terminal")
                                            .foregroundColor(selectedCommand == file ? .white : .green)
                                        Text(file.lastPathComponent).font(.system(size: 11))
                                        Spacer()
                                    }
                                    .padding(6)
                                    .background(selectedCommand == file ? Color.accentColor : Color.clear)
                                    .cornerRadius(4)
                                    .contentShape(Rectangle())
                                    .onTapGesture { selectedCommand = file }
                                }
                            }
                        }
                    }
                }
                .frame(height: 220)            }

            Button {
                if let cmd = selectedCommand {
                    TerminalEngine.runCommand(at: cmd)
                }
            } label: {
                HStack {
                    Image(systemName: "terminal")
                    Text("Run Terminal Command")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(FilledButton(color: .black))
            .disabled(selectedCommand == nil)
        }
        .padding(14)
        .frame(maxHeight: .infinity, alignment: .top)
        .onAppear { autoDetectFolder() }
        .sheet(isPresented: $showingCreator) {
            ScriptCreatorView(folderURL: folderURL)
        }
    }

    private func autoDetectFolder() {
        let fm = FileManager.default
        let desktop = fm.urls(for: .desktopDirectory, in: .userDomainMask)[0]
        let url = desktop.appendingPathComponent("Scripts")
        if fm.fileExists(atPath: url.path) {
            self.folderURL = url
            loadCommands(from: url)
        }
    }

    private func selectFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        if panel.runModal() == .OK {
            self.folderURL = panel.url
            loadCommands(from: panel.url!)
        }
    }

    private func loadCommands(from url: URL) {
        do {
            let files = try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)
            self.commandFiles = files.filter { $0.pathExtension.lowercased() == "sh" }
                .sorted(by: { $0.lastPathComponent < $1.lastPathComponent })
        } catch { print("Access Error") }
    }
}


// MARK: - Screenshot Engine

final class ScreenshotEngine {

    static func listWindows() -> [WindowInfo] {
        guard let list = CGWindowListCopyWindowInfo(
            [.optionOnScreenOnly, .excludeDesktopElements],
            kCGNullWindowID
        ) as? [[String: Any]] else { return [] }

        return list.compactMap { info -> WindowInfo? in
            guard
                let wid   = info[kCGWindowNumber    as String] as? Int,
                let owner = info[kCGWindowOwnerName as String] as? String,
                let pid   = info[kCGWindowOwnerPID  as String] as? pid_t,
                pid != ProcessInfo.processInfo.processIdentifier
            else { return nil }

            // Allow all window layers (layer 0 = normal, higher = floating/dialog)
            // This ensures osascript alerts, system dialogs etc. are all listed.
            // Filter out tiny windows (< 60px) that are likely system chrome.
            if let bounds = info[kCGWindowBounds as String] as? [String: CGFloat] {
                let w = bounds["Width"]  ?? 0
                let h = bounds["Height"] ?? 0
                if w < 60 || h < 30 { return nil }
            }

            let name = info[kCGWindowName as String] as? String ?? ""
            return WindowInfo(id: wid, name: name, ownerName: owner, pid: pid)
        }
    }

    // WITH shadow
    static func capture(
        windowID: Int,
        pid: pid_t,
        mode: CaptureMode,
        to url: URL,
        done: @escaping (Bool, String) -> Void
    ) {
        switch mode {
        case .active:
            NSApp.activate(ignoringOtherApps: true)

            if let infoList = CGWindowListCopyWindowInfo([.optionIncludingWindow], CGWindowID(windowID)) as? [[String: Any]],
               let ownerPID = infoList.first?[kCGWindowOwnerPID as String] as? pid_t {

                NSRunningApplication(processIdentifier: ownerPID)?
                    .activate(options: [.activateIgnoringOtherApps, .activateAllWindows])
            }

            waitForFrontmost(pid: pid) {
                performCapture(windowID: windowID, url: url, noShadow: false, done: done)
            }
            return

        case .inactive:
            NSApp.activate(ignoringOtherApps: true)
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            performCapture(windowID: windowID, url: url, noShadow: false, done: done)
        }
        // Use 1.2s delay — osascript/dialog windows need more time to settle
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            let task        = Process()
            task.launchPath = "/usr/sbin/screencapture"
            task.arguments  = ["-l", "\(windowID)", url.path]
            task.launch()
            task.waitUntilExit()

            if task.terminationStatus == 0 {
                // Verify file actually has content (screencapture can exit 0 but write nothing
                // for privileged/sandboxed windows like osascript alerts on Monterey+)
                let size = (try? FileManager.default.attributesOfItem(atPath: url.path))?[.size] as? Int ?? 0
                if size > 1000 {
                    done(true, "Saved: \(url.lastPathComponent)")
                } else {
                    // Fallback: use CGWindowListCreateImage which can capture more window types
                    captureFallback(windowID: windowID, to: url, noShadow: false, done: done)
                }
            } else {
                // Fallback for privileged windows
                captureFallback(windowID: windowID, to: url, noShadow: false, done: done)
            }
        }
    }

    // WITHOUT shadow (-o flag)
    static func captureNoShadow(
        windowID: Int,
        pid: pid_t,
        mode: CaptureMode,
        to url: URL,
        done: @escaping (Bool, String) -> Void
    ) {
        switch mode {
        case .active:
            NSApp.activate(ignoringOtherApps: true)

            if let infoList = CGWindowListCopyWindowInfo([.optionIncludingWindow], CGWindowID(windowID)) as? [[String: Any]],
               let ownerPID = infoList.first?[kCGWindowOwnerPID as String] as? pid_t {

                NSRunningApplication(processIdentifier: ownerPID)?
                    .activate(options: [.activateIgnoringOtherApps, .activateAllWindows])
            }
        case .inactive:
            NSApp.activate(ignoringOtherApps: true)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            let task        = Process()
            task.launchPath = "/usr/sbin/screencapture"
            task.arguments  = ["-o", "-l", "\(windowID)", url.path]
            task.launch()
            task.waitUntilExit()

            if task.terminationStatus == 0 {
                let size = (try? FileManager.default.attributesOfItem(atPath: url.path))?[.size] as? Int ?? 0
                if size > 1000 {
                    done(true, "Saved: \(url.lastPathComponent)")
                } else {
                    captureFallback(windowID: windowID, to: url, noShadow: true, done: done)
                }
            } else {
                captureFallback(windowID: windowID, to: url, noShadow: true, done: done)
            }
        }
    }

    /// Fallback capture using CGWindowListCreateImage — works for osascript alerts,
    /// system dialogs, and other windows that screencapture -l cannot access.
    /// CGWindowListCreateImage does not require the window to be at layer 0.
    static func captureFallback(windowID: Int, to url: URL, noShadow: Bool, done: @escaping (Bool, String) -> Void) {
        let option: CGWindowImageOption = noShadow
            ? [.boundsIgnoreFraming, .nominalResolution]
            : [.nominalResolution]

        guard let cgImage = CGWindowListCreateImage(
            .null,
            .optionIncludingWindow,
            CGWindowID(windowID),
            option
        ) else {
            done(false, "Could not capture window (permission denied or window gone)")
            return
        }

        let rep = NSBitmapImageRep(cgImage: cgImage)
        guard let png = rep.representation(using: .png, properties: [:]) else {
            done(false, "Could not encode image")
            return
        }

        do {
            try png.write(to: url)
            done(true, "Saved: \(url.lastPathComponent)")
        } catch {
            done(false, "Could not write file: \(error.localizedDescription)")
        }
    }

    enum CaptureMode { case active, inactive }
}


func waitForFrontmost(pid: pid_t, timeout: TimeInterval = 2.0, completion: @escaping () -> Void) {
    let start = Date()
    
    func check() {
        if NSWorkspace.shared.frontmostApplication?.processIdentifier == pid {
            completion()
            return
        }
        
        if Date().timeIntervalSince(start) > timeout {
            completion() // fallback
            return
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            check()
        }
    }
    
    check()
}

func performCapture(windowID: Int, url: URL, noShadow: Bool, done: @escaping (Bool, String) -> Void) {
    let task = Process()
    task.launchPath = "/usr/sbin/screencapture"
    
    if noShadow {
        task.arguments = ["-o", "-l", "\(windowID)", url.path]
    } else {
        task.arguments = ["-l", "\(windowID)", url.path]
    }

    task.launch()
    task.waitUntilExit()

    if task.terminationStatus == 0 {
        let size = (try? FileManager.default.attributesOfItem(atPath: url.path))?[.size] as? Int ?? 0
        if size > 1000 {
            done(true, "Saved: \(url.lastPathComponent)")
        } else {
            ScreenshotEngine.captureFallback(windowID: windowID, to: url, noShadow: noShadow, done: done)
        }
    } else {
        ScreenshotEngine.captureFallback(windowID: windowID, to: url, noShadow: noShadow, done: done)
    }
}

// MARK: - Scriptengine

final class TerminalEngine {
    static func runCommand(at url: URL) {
        let task = Process()
        // We use zsh because it is the modern macOS default
        task.launchPath = "/bin/zsh"
        task.arguments = [url.path]
        
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try task.run()
                task.waitUntilExit()
            } catch {
                print("Failed to run terminal command: \(error)")
            }
        }
    }
}

// MARK: - Notification Manager

final class NotificationManager: ObservableObject {
    @Published var granted = false

    func requestPermission() {
        UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
                DispatchQueue.main.async { self.granted = ok }
            }
    }

    func checkPermission() {
        UNUserNotificationCenter.current().getNotificationSettings { s in
            DispatchQueue.main.async {
                self.granted = (s.authorizationStatus == .authorized)
            }
        }
    }

    func send(title: String, subtitle: String, body: String, sound: Bool) {
        let script = """
        display notification "\(body)" with title "\(title)"\(subtitle.isEmpty ? "" : " subtitle \"\(subtitle)\"")\(sound ? " sound name \"default\"" : "")
        """
        let task = Process()
        task.launchPath = "/usr/bin/osascript"
        task.arguments  = ["-e", script]
        task.launch()
    }
}



// MARK: - Notification Icon

enum NotifIcon: String, CaseIterable, Identifiable {
    case whatsapp = "WhatsApp"
    case messages = "Messages"
    case settings = "Settings"
    case mail     = "Mail"
    case facetime = "FaceTime"
    case twitter  = "Twitter"
    case custom   = "Bell"

    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .whatsapp: return "message.badge.filled.fill"
        case .messages: return "message.fill"
        case .settings: return "gearshape.fill"
        case .mail:     return "envelope.fill"
        case .facetime: return "video.fill"
        case .twitter:  return "bird.fill"
        case .custom:   return "bell.fill"
        }
    }

    var color: Color {
        switch self {
        case .whatsapp: return Color(red: 0.13, green: 0.74, blue: 0.40)
        case .messages: return Color(red: 0.20, green: 0.78, blue: 0.35)
        case .settings: return Color(red: 0.55, green: 0.55, blue: 0.57)
        case .mail:     return Color(red: 0.20, green: 0.45, blue: 0.90)
        case .facetime: return Color(red: 0.29, green: 0.80, blue: 0.35)
        case .twitter:  return Color(red: 0.11, green: 0.63, blue: 0.95)
        case .custom:   return Color(red: 0.90, green: 0.45, blue: 0.10)
        }
    }
}


// MARK: - Shared UI Helpers

struct SectionLabel: View {
    let text: String
    var body: some View {
        Text(text.uppercased())
            .font(.system(size: 9.5, weight: .semibold, design: .rounded))
            .foregroundColor(.secondary)
            .tracking(0.7)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct FilledButton: ButtonStyle {
    var color: Color
    var wide: Bool = true
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 12, weight: .semibold))
            .padding(.vertical, 9)
            .padding(.horizontal, 14)
            .frame(maxWidth: wide ? .infinity : nil)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(color.opacity(configuration.isPressed ? 0.70 : 1.0))
            )
            .foregroundColor(.white)
            .scaleEffect(configuration.isPressed ? 0.985 : 1.0)
            .animation(.easeOut(duration: 0.07), value: configuration.isPressed)
    }
}

struct CardBox<Content: View>: View {
    @ViewBuilder let content: () -> Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) { content() }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(Color(NSColor.controlBackgroundColor))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .strokeBorder(Color(NSColor.separatorColor).opacity(0.55), lineWidth: 1)
            )
    }
}

// MARK: - Screenshot Tab

struct ScreenshotTab: View {
    @State private var windows: [WindowInfo] = []
    @State private var selected: WindowInfo? = nil
    @State private var folder: URL = FileManager.default.urls(for: .picturesDirectory, in: .userDomainMask)[0]
    @State private var status  = "Select a window, then capture."
    @State private var busy    = false
    @State private var lastOK  = false
    @State private var lastURL: URL? = nil
    @State private var screenRecordingGranted: Bool = true

    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {

                    // ── Screen Recording Permission Banner ─────────────
                    if !screenRecordingGranted {
                        HStack(spacing: 12) {
                            Image(systemName: "camera.badge.exclamationmark")
                                .foregroundColor(.orange)
                                .font(.system(size: 18))
                            VStack(alignment: .leading, spacing: 3) {
                                Text("Screen Recording Permission Required")
                                    .font(.system(size: 12, weight: .semibold))
                                Text("Open System Settings → Privacy & Security → Screen Recording → enable MacToast.")
                                    .font(.system(size: 10.5))
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Button("Open Settings") {
                                NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture")!)
                            }
                            .buttonStyle(FilledButton(color: .orange, wide: false))
                        }
                        .padding(12)
                        .background(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .fill(Color.orange.opacity(0.10))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .strokeBorder(Color.orange.opacity(0.30), lineWidth: 1)
                                )
                        )
                    }

                    // ── Window picker ──────────────────────────────────
                    CardBox {
                        SectionLabel(text: "Target Window")
                        HStack(spacing: 8) {
                            Picker("", selection: $selected) {
                                Text("— Select a window —").tag(Optional<WindowInfo>(nil))
                                ForEach(windows) { w in
                                    Text(w.displayName).tag(Optional(w))
                                }
                            }
                            .labelsHidden()
                            .frame(maxWidth: .infinity)

                            Button {
                                windows = ScreenshotEngine.listWindows()
                            } label: {
                                Image(systemName: "arrow.clockwise")
                                    .font(.system(size: 12, weight: .medium))
                            }
                            .buttonStyle(.borderless)
                            .help("Refresh window list")
                        }
                    }

                    // ── Capture with shadow ────────────────────────────
                    CardBox {
                        SectionLabel(text: "Capture With Shadow")

                        Button { go(.active) } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "camera.fill")
                                    .font(.system(size: 16)).frame(width: 22)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Active Screenshot")
                                        .font(.system(size: 13, weight: .semibold))
                                    Text("Focuses window → coloured title bar + shadow")
                                        .font(.system(size: 10.5)).opacity(0.82)
                                }
                                Spacer()
                                Text("⌃B")
                                    .font(.system(size: 11, design: .monospaced)).opacity(0.6)
                            }
                        }
                        .buttonStyle(FilledButton(color: Color(red: 0.18, green: 0.48, blue: 0.96)))
                        .disabled(selected == nil || busy)

                        Button { go(.inactive) } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "camera")
                                    .font(.system(size: 16)).frame(width: 22)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Inactive Screenshot")
                                        .font(.system(size: 13, weight: .semibold))
                                    Text("Stays in background → grey title bar + shadow")
                                        .font(.system(size: 10.5)).opacity(0.82)
                                }
                                Spacer()
                                Text("⌃⇧B")
                                    .font(.system(size: 11, design: .monospaced)).opacity(0.6)
                            }
                        }
                        .buttonStyle(FilledButton(color: Color(red: 0.36, green: 0.36, blue: 0.40)))
                        .disabled(selected == nil || busy)

                        Button { captureBoth() } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "camera.badge.ellipsis")
                                    .font(.system(size: 16)).frame(width: 22)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Capture Both")
                                        .font(.system(size: 13, weight: .semibold))
                                    Text("Active + inactive, smaller padded to match larger")
                                        .font(.system(size: 10.5)).opacity(0.82)
                                }
                                Spacer()
                            }
                        }
                        .buttonStyle(FilledButton(color: Color(red: 0.55, green: 0.20, blue: 0.90)))
                        .disabled(selected == nil || busy)
                    }

                    // ── Capture without shadow ─────────────────────────
                    CardBox {
                        SectionLabel(text: "Capture Without Shadow")

                        Button { goNoShadow(.active) } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "camera.fill")
                                    .font(.system(size: 16)).frame(width: 22)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Active Screenshot (No Shadow)")
                                        .font(.system(size: 13, weight: .semibold))
                                    Text("Focuses window → coloured title bar, no shadow")
                                        .font(.system(size: 10.5)).opacity(0.82)
                                }
                                Spacer()
                            }
                        }
                        .buttonStyle(FilledButton(color: Color(red: 0.18, green: 0.48, blue: 0.96).opacity(0.6)))
                        .disabled(selected == nil || busy)

                        Button { goNoShadow(.inactive) } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "camera")
                                    .font(.system(size: 16)).frame(width: 22)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Inactive Screenshot (No Shadow)")
                                        .font(.system(size: 13, weight: .semibold))
                                    Text("Stays in background → grey title bar, no shadow")
                                        .font(.system(size: 10.5)).opacity(0.82)
                                }
                                Spacer()
                            }
                        }
                        .buttonStyle(FilledButton(color: Color(red: 0.36, green: 0.36, blue: 0.40).opacity(0.6)))
                        .disabled(selected == nil || busy)

                        Button { captureBothNoShadow() } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "camera.badge.ellipsis")
                                    .font(.system(size: 16)).frame(width: 22)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Capture Both (No Shadow)")
                                        .font(.system(size: 13, weight: .semibold))
                                    Text("Active + inactive, no shadow, perfect same size")
                                        .font(.system(size: 10.5)).opacity(0.82)
                                }
                                Spacer()
                            }
                        }
                        .buttonStyle(FilledButton(color: Color(red: 0.55, green: 0.20, blue: 0.90).opacity(0.6)))
                        .disabled(selected == nil || busy)
                    }

                    // ── Save folder ────────────────────────────────────
                    CardBox {
                        SectionLabel(text: "Save Location")

                        HStack(spacing: 8) {
                            Image(systemName: "folder.fill")
                                .foregroundColor(Color(NSColor.controlAccentColor))
                                .font(.system(size: 14))
                            Text(folder.path)
                                .font(.system(size: 11))
                                .lineLimit(1)
                                .truncationMode(.middle)
                            Spacer()
                            Button("Change…") { pickFolder() }
                                .font(.system(size: 11))
                                .buttonStyle(.borderless)
                        }
                        .padding(9)
                        .background(
                            RoundedRectangle(cornerRadius: 7, style: .continuous)
                                .fill(Color(NSColor.windowBackgroundColor))
                        )

                        Button {
                            NSWorkspace.shared.open(folder)
                        } label: {
                            Label("Open Screenshots Folder", systemImage: "arrow.up.right.square")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(FilledButton(color: Color(red: 0.18, green: 0.65, blue: 0.34)))
                    }
                }
                .padding(14)
            }

            // ── Status bar ─────────────────────────────────────────────
            Divider()
            HStack(spacing: 8) {
                if busy {
                    ProgressView().scaleEffect(0.55).frame(width: 14, height: 14)
                } else {
                    Image(systemName: lastOK ? "checkmark.circle.fill" : "info.circle.fill")
                        .foregroundColor(lastOK ? .green : .secondary)
                        .font(.system(size: 11))
                }
                Text(status)
                    .font(.system(size: 10.5))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Spacer()
                if let u = lastURL {
                    Button("Show in Finder") {
                        NSWorkspace.shared.activateFileViewerSelecting([u])
                    }
                    .font(.system(size: 10))
                    .buttonStyle(.borderless)
                }
            }
            .padding(.horizontal, 14)
            .frame(height: 34)
        }
        .onAppear {
            checkScreenRecordingPermission()
            windows = ScreenshotEngine.listWindows()
            registerHotkeys()
        }
    }

    // MARK: - Actions

    private func pickFolder() {
        let p = NSOpenPanel()
        p.canChooseDirectories    = true
        p.canChooseFiles          = false
        p.allowsMultipleSelection = false
        p.prompt                  = "Choose"
        guard p.runModal() == .OK, let u = p.url else { return }
        folder = u
    }

    private func go(_ mode: ScreenshotEngine.CaptureMode) {
        guard let win = selected else { return }
        busy = true; lastURL = nil; lastOK = false
        let tag  = mode == .active ? "active" : "inactive"
        let ts   = Int(Date().timeIntervalSince1970)
        let name = "\(win.ownerName)_\(tag)_\(ts).png"
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
        let dest = folder.appendingPathComponent(name)
        status = "Capturing \(tag)…"
        ScreenshotEngine.capture(windowID: win.id, pid: win.pid, mode: mode, to: dest) { ok, msg in
            DispatchQueue.main.async {
                busy = false; lastOK = ok
                status = ok ? "✓ \(name)" : "✗ \(msg)"
                if ok { lastURL = dest }
            }
        }
    }

    private func goNoShadow(_ mode: ScreenshotEngine.CaptureMode) {
        guard let win = selected else { return }
        busy = true; lastURL = nil; lastOK = false
        let tag  = mode == .active ? "active" : "inactive"
        let ts   = Int(Date().timeIntervalSince1970)
        let name = "\(win.ownerName)_\(tag)_noshadow_\(ts).png"
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
        let dest = folder.appendingPathComponent(name)
        status = "Capturing \(tag) (no shadow)…"
        ScreenshotEngine.captureNoShadow(windowID: win.id, pid: win.pid, mode: mode, to: dest) { ok, msg in
            DispatchQueue.main.async {
                busy = false; lastOK = ok
                status = ok ? "✓ \(name)" : "✗ \(msg)"
                if ok { lastURL = dest }
            }
        }
    }

    private func captureBoth() {
        guard let win = selected else { return }
        busy = true; lastURL = nil; lastOK = false
        let ts           = Int(Date().timeIntervalSince1970)
        let activeName   = "\(win.ownerName)_active_\(ts).png"
            .replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
        let inactiveName = "\(win.ownerName)_inactive_\(ts).png"
            .replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
        let activeDest   = folder.appendingPathComponent(activeName)
        let inactiveDest = folder.appendingPathComponent(inactiveName)
        status = "Capturing active - do not touch anything…"
        ScreenshotEngine.capture(windowID: win.id, pid: win.pid, mode: .active, to: activeDest) { ok1, _ in
            guard ok1 else {
                DispatchQueue.main.async { busy = false; status = "Active capture failed" }
                return
            }
            DispatchQueue.main.async { status = "Capturing inactive - do not touch anything…" }
            ScreenshotEngine.capture(windowID: win.id, pid: win.pid, mode: .inactive, to: inactiveDest) { ok2, _ in
                guard ok2 else {
                    DispatchQueue.main.async { busy = false; status = "Inactive capture failed" }
                    return
                }
                DispatchQueue.main.async {
                    matchSizes(url1: activeDest, url2: inactiveDest, windowID: win.id)
                    busy = false; lastOK = true; lastURL = activeDest
                    status = "Both screenshots are now saved!"
                }
            }
        }
    }

    private func captureBothNoShadow() {
        guard let win = selected else { return }
        busy = true; lastURL = nil; lastOK = false
        let ts           = Int(Date().timeIntervalSince1970)
        let activeName   = "\(win.ownerName)_active_noshadow_\(ts).png"
            .replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
        let inactiveName = "\(win.ownerName)_inactive_noshadow_\(ts).png"
            .replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
        let activeDest   = folder.appendingPathComponent(activeName)
        let inactiveDest = folder.appendingPathComponent(inactiveName)
        status = "Capturing active (no shadow)…"
        ScreenshotEngine.captureNoShadow(windowID: win.id, pid: win.pid, mode: .active, to: activeDest) { ok1, _ in
            guard ok1 else {
                DispatchQueue.main.async { busy = false; status = "✗ Active capture failed" }
                return
            }
            DispatchQueue.main.async { status = "Capturing inactive (no shadow)…" }
            ScreenshotEngine.captureNoShadow(windowID: win.id, pid: win.pid, mode: .inactive, to: inactiveDest) { ok2, _ in
                DispatchQueue.main.async {
                    busy = false; lastOK = ok2; lastURL = activeDest
                    status = ok2 ? "✓ Both saved, no shadow, identical size!" : "✗ Inactive failed"
                }
            }
        }
    }

    // Aligns both images so the window sits at the exact same pixel position.
    // The active shadow is larger than inactive, so both images are different sizes.
    // Key insight: the window itself is always centered inside its screenshot with
    // equal shadow on each side. So shadow offset = (imgSize - windowSize) / 2.
    // Window size = the smaller of the two (less shadow = closer to true window size).
    // We pin both windows to the same top-left and use the active image as the canvas.
    private func matchSizes(url1: URL, url2: URL, windowID: Int) {
        guard let img1 = NSImage(contentsOf: url1),
              let img2 = NSImage(contentsOf: url2),
              let cgImg1 = img1.cgImage(forProposedRect: nil, context: nil, hints: nil),
              let cgImg2 = img2.cgImage(forProposedRect: nil, context: nil, hints: nil)
        else { return }

        // Real pixel sizes
        let pw1 = CGFloat(cgImg1.width),  ph1 = CGFloat(cgImg1.height)
        let pw2 = CGFloat(cgImg2.width),  ph2 = CGFloat(cgImg2.height)
        let scale = pw1 / img1.size.width  // retina scale factor

        // Get the real window position and size from CGWindowList
        // Try both optionIncludingWindow and optionOnScreenOnly to handle timing
        let windowList = (CGWindowListCopyWindowInfo([.optionIncludingWindow], CGWindowID(windowID)) as? [[String: Any]]) ??
                         (CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] ?? [])
        guard let info = windowList.first(where: { ($0[kCGWindowNumber as String] as? Int) == windowID }),
              let bounds = info[kCGWindowBounds as String] as? [String: CGFloat],
              let winW  = bounds["Width"],
              let winH  = bounds["Height"]
        else { return }

        
        // The window in each screenshot starts at:
        //   screenshotX = winX * scale  (window left edge in screenshot pixels)
        //   but the screenshot itself starts at (winX - shadowLeft) * scale
        // So: shadowLeft (in screen pts) = (imgWidth/scale - winW) ... not reliable
        // Better: the screenshot LEFT edge in screen coords =
        //   imgLeft_screen = winX - (img.size.width - winW) / 2  -- if shadow symmetric
        // Instead use the REAL approach: CGWindowList gives us screen coords of the window.
        // The screenshot captures from (winX - shadowLeft) to (winX + winW + shadowRight).
        // Shadow is NOT symmetric, so we measure it directly:
        //   For img1: we know winW in screen pts, img1 width in screen pts = pw1/scale
        //   The window occupies winW pts inside the img of (pw1/scale) pts total.
        //   We don't know where inside img1 the window is without guessing.
        // REAL SOLUTION: use NSScreen to get display scale, then use window screen origin.
        // The screenshot starts at the window's bounding box origin on screen minus shadow.
        // screencapture always starts the image at the window frame minus shadow.
        // So: window left edge within img1 (in pixels) = (winX - img1_screen_left) * scale
        // img1_screen_left = winX - shadowLeft_pts
        // We don't know shadowLeft_pts directly, BUT:
        //   img1 width in pts = pw1 / scale
        //   img1 height in pts = ph1 / scale
        //   shadow total horizontal = img1_width_pts - winW
        //   shadow total vertical   = img1_height_pts - winH
        // Assume shadow is NOT symmetric — left shadow may differ from right.
        // BUT: screencapture centers the window in the shadow for -l captures.
        // So: shadowLeft = shadowRight = (img_width_pts - winW) / 2
        // This gives us exact window position within each image in pixels:
        let img1_w_pts = pw1 / scale
        let img1_h_pts = ph1 / scale
        let img2_w_pts = pw2 / scale
        let img2_h_pts = ph2 / scale

        // Window offset inside each image (in points, then convert to pixels)
        let winOffX1 = ((img1_w_pts - winW) / 2) * scale  // pixels from left in img1
        let winOffY1 = ((img1_h_pts - winH) / 2) * scale  // pixels from top in img1
        let winOffX2 = ((img2_w_pts - winW) / 2) * scale  // pixels from left in img2
        let winOffY2 = ((img2_h_pts - winH) / 2) * scale  // pixels from top in img2

        // Canvas = img1 size exactly
        let canvasW = pw1
        let canvasH = ph1

        // Place img2 so its window aligns with img1's window:
        // img2 should be offset by (winOffX1 - winOffX2) from left
        // img2 should be offset by (winOffY1 - winOffY2) from top
        let placeX_px = winOffX1 - winOffX2          // pixels from left
        // Active window top shadow > inactive, so inactive needs to sit higher
        // winOffY1 = active top shadow (bigger), winOffY2 = inactive top shadow (smaller)
        // inactive needs to go DOWN by the difference to align windows
        let placeY_fromTop_px = winOffY1 - winOffY2

        // NSImage draws from bottom-left, so flip Y:
        let placeY_ns_px = canvasH + placeY_fromTop_px - ph2 - 68

        let canvas = NSImage(size: NSSize(width: canvasW / scale, height: canvasH / scale))
        canvas.lockFocus()
        img2.draw(in: NSRect(
            x:      placeX_px      / scale,
            y:      placeY_ns_px   / scale,
            width:  img2.size.width,
            height: img2.size.height
        ))
        canvas.unlockFocus()

        if let tiff = canvas.tiffRepresentation,
           let rep  = NSBitmapImageRep(data: tiff),
           let png  = rep.representation(using: .png, properties: [:]) {
            try? png.write(to: url2)
        }
        // img1 stays as-is — it is already the correct canvas
    }

    // kept for legacy call compatibility — not used by matchSizes anymore
    private func padImage(_ img: NSImage, to size: NSSize, saveTo url: URL) {
        guard img.size.width != size.width || img.size.height != size.height else { return }
        let new = NSImage(size: size)
        new.lockFocus()
        let x = (size.width  - img.size.width)  / 2
        let y = (size.height - img.size.height) / 2
        img.draw(in: NSRect(x: x, y: y, width: img.size.width, height: img.size.height))
        new.unlockFocus()
        if let tiff = new.tiffRepresentation,
           let rep  = NSBitmapImageRep(data: tiff),
           let png  = rep.representation(using: .png, properties: [:]) {
            try? png.write(to: url)
        }
    }

    private func checkScreenRecordingPermission() {
        // CGWindowListCopyWindowInfo returns empty or only our own windows if
        // Screen Recording permission has not been granted yet.
        let list = CGWindowListCopyWindowInfo(
            [.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID
        ) as? [[String: Any]] ?? []
        let othersVisible = list.contains { info in
            if let pid = info[kCGWindowOwnerPID as String] as? pid_t {
                return pid != ProcessInfo.processInfo.processIdentifier
            }
            return false
        }
        screenRecordingGranted = othersVisible
    }

    private func registerHotkeys() {
        NSEvent.addLocalMonitorForEvents(matching: .keyDown) { e in
            let ctrl    = e.modifierFlags.contains(.control)
            let opt     = e.modifierFlags.contains(.option)
            let cmd     = e.modifierFlags.contains(.command)
            let shift   = e.modifierFlags.contains(.shift)
            let key     = e.charactersIgnoringModifiers?.lowercased()

            // ⌃B → active, ⌃⇧B → inactive
            if ctrl && !opt && !cmd && key == "b" {
                go(shift ? .inactive : .active)
                return nil
            }

            // ⌃⌥C → Capture Both (with shadow)
            if ctrl && opt && !cmd && key == "c" {
                captureBoth()
                return nil
            }

            // ⌃⌥⌘C → Capture Both (no shadow)
            if ctrl && opt && cmd && key == "c" {
                captureBothNoShadow()
                return nil
            }

            return e
        }
    }
}

// MARK: - Notification Preview Card

struct NotifPreviewCard: View {
    let appName: String
    let title: String
    let subtitle: String
    let bodyText: String
    let icon: NotifIcon

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(icon.color)
                    .frame(width: 40, height: 40)
                    .shadow(color: icon.color.opacity(0.30), radius: 4, y: 2)
                Image(systemName: icon.symbol)
                    .font(.system(size: 18))
                    .foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Text(appName.uppercased())
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(.secondary)
                        .tracking(0.4)
                    Spacer()
                    Text("now").font(.system(size: 9)).foregroundColor(.secondary)
                }
                Text(title).font(.system(size: 12, weight: .semibold)).lineLimit(1)
                if !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(.secondary).lineLimit(1)
                }
                Text(bodyText)
                    .font(.system(size: 11))
                    .foregroundColor(Color(NSColor.secondaryLabelColor))
                    .lineLimit(2)
            }
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(NSColor.windowBackgroundColor))
                .shadow(color: Color.black.opacity(0.13), radius: 8, y: 3)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .strokeBorder(Color(NSColor.separatorColor).opacity(0.4), lineWidth: 1)
        )
    }
}

// MARK: - Notifications Tab

struct NotificationsTab: View {
    @StateObject private var mgr = NotificationManager()

    @State private var appName  = "WhatsApp"
    @State private var title    = "John Appleseed"
    @State private var subtitle = ""
    @State private var bodyText = "Hey, are you free tonight? 🎉"
    @State private var icon: NotifIcon = .whatsapp
    @State private var sound    = true
    @State private var repeatN: Double = 1
    @State private var statusTxt = ""
    @State private var sending   = false

    private let presets: [(String, NotifIcon, String, String)] = [
        ("WhatsApp",  .whatsapp, "John Appleseed",     "Hey, are you free tonight? 🎉"),
        ("Messages",  .messages, "Mom",                 "Don't forget dinner at 7!"),
        ("Settings",  .settings, "Software Update",     "macOS update is available."),
        ("Mail",      .mail,     "Apple",               "Your receipt from the App Store."),
        ("FaceTime",  .facetime, "Incoming Video Call", "Sarah is calling…"),
        ("Twitter",   .twitter,  "Twitter",             "You have 12 new notifications."),
    ]

    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {

                if !mgr.granted {
                    HStack(spacing: 12) {
                        Image(systemName: "bell.slash.fill")
                            .foregroundColor(.orange).font(.system(size: 18))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Notification Permission Required")
                                .font(.system(size: 12, weight: .semibold))
                            Text("Click Grant, then allow in System Preferences → Notifications.")
                                .font(.system(size: 10.5)).foregroundColor(.secondary)
                        }
                        Spacer()
                        Button("Grant") { mgr.requestPermission() }
                            .buttonStyle(FilledButton(color: .orange, wide: false))
                    }
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(Color.orange.opacity(0.10))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .strokeBorder(Color.orange.opacity(0.30), lineWidth: 1)
                            )
                    )
                }

                CardBox {
                    SectionLabel(text: "Quick App Presets")
                    LazyVGrid(
                        columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 3),
                        spacing: 8
                    ) {
                        ForEach(presets, id: \.0) { p in
                            Button { applyPreset(p) } label: {
                                HStack(spacing: 6) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 5, style: .continuous)
                                            .fill(p.1.color).frame(width: 18, height: 18)
                                        Image(systemName: p.1.symbol)
                                            .font(.system(size: 9)).foregroundColor(.white)
                                    }
                                    Text(p.0).font(.system(size: 11, weight: .medium)).lineLimit(1)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 7)
                                .background(
                                    RoundedRectangle(cornerRadius: 7, style: .continuous)
                                        .fill(icon == p.1
                                              ? p.1.color.opacity(0.18)
                                              : Color(NSColor.controlBackgroundColor))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 7, style: .continuous)
                                                .strokeBorder(
                                                    icon == p.1
                                                    ? p.1.color.opacity(0.55)
                                                    : Color(NSColor.separatorColor).opacity(0.4),
                                                    lineWidth: 1
                                                )
                                        )
                                )
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                }

                CardBox {
                    SectionLabel(text: "App Icon Style")
                    HStack(spacing: 10) {
                        ForEach(NotifIcon.allCases) { i in
                            Button {
                                withAnimation(.spring(response: 0.2)) { icon = i }
                            } label: {
                                VStack(spacing: 4) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 9, style: .continuous)
                                            .fill(i.color).frame(width: 34, height: 34)
                                            .shadow(
                                                color: icon == i ? i.color.opacity(0.45) : .clear,
                                                radius: 5, y: 2
                                            )
                                        Image(systemName: i.symbol)
                                            .font(.system(size: 14)).foregroundColor(.white)
                                    }
                                    Text(i.rawValue)
                                        .font(.system(size: 8.5, weight: icon == i ? .semibold : .regular))
                                        .foregroundColor(icon == i ? i.color : .secondary)
                                        .lineLimit(1)
                                }
                                .opacity(icon == i ? 1 : 0.5)
                                .scaleEffect(icon == i ? 1.08 : 1)
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }

                CardBox {
                    SectionLabel(text: "Notification Content")
                    notifField("App Name", placeholder: "e.g. WhatsApp",    text: $appName)
                    notifField("Title",    placeholder: "Sender or subject", text: $title)
                    notifField("Subtitle", placeholder: "Optional",          text: $subtitle)

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Body")
                            .font(.system(size: 10.5, weight: .medium))
                            .foregroundColor(.secondary)
                        TextEditor(text: $bodyText)
                            .font(.system(size: 11.5))
                            .frame(minHeight: 80, maxHeight: 120) // Adjust as needed for better height
                            .padding(5)
                            .background(
                                RoundedRectangle(cornerRadius: 6, style: .continuous)
                                    .fill(Color(NSColor.textBackgroundColor))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                                            .strokeBorder(Color(NSColor.separatorColor), lineWidth: 1)
                                    )
                            )
                    }
                }

                CardBox {
                    SectionLabel(text: "Options")
                    Toggle(isOn: $sound) {
                        Label("Play notification sound", systemImage: "speaker.wave.2.fill")
                            .font(.system(size: 11.5))
                    }
                    .toggleStyle(.checkbox)

                    HStack(spacing: 10) {
                        Label("Repeat  \(Int(repeatN))×", systemImage: "repeat")
                            .font(.system(size: 11.5))
                            .frame(width: 88, alignment: .leading)
                        Slider(value: $repeatN, in: 1...10, step: 1)
                    }
                }

                CardBox {
                    SectionLabel(text: "Live Preview")
                    NotifPreviewCard(
                        appName:  appName.isEmpty   ? "App"     : appName,
                        title:    title.isEmpty     ? "Title"   : title,
                        subtitle: subtitle,
                        bodyText: bodyText.isEmpty  ? "Message" : bodyText,
                        icon:     icon
                    )
                }

                Button { sendAll() } label: {
                    HStack(spacing: 8) {
                        if sending {
                            ProgressView().scaleEffect(0.6).frame(width: 14, height: 14)
                        } else {
                            Image(systemName: "bell.badge.fill")
                        }
                        Text("Send Notification\(Int(repeatN) > 1 ? " ×\(Int(repeatN))" : "")")
                            .font(.system(size: 13, weight: .semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 2)
                }
                .buttonStyle(FilledButton(color: icon.color))
                .disabled(sending)

                if !statusTxt.isEmpty {
                    Text(statusTxt)
                        .font(.system(size: 10.5))
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .center)
                }
            }
            .padding(14)
        }
        .onAppear { mgr.checkPermission() }
    }

    @ViewBuilder
    private func notifField(_ label: String, placeholder: String, text: Binding<String>) -> some View {
        HStack(spacing: 8) {
            Text(label)
                .font(.system(size: 10.5, weight: .medium))
                .foregroundColor(.secondary)
                .frame(width: 62, alignment: .trailing)
            TextField(placeholder, text: text)
                .textFieldStyle(.roundedBorder)
                .font(.system(size: 11.5))
        }
    }

    private func applyPreset(_ p: (String, NotifIcon, String, String)) {
        appName = p.0; icon = p.1; title = p.2; subtitle = ""; bodyText = p.3
    }

    private func sendAll() {
        let count = Int(repeatN)
        sending = true; statusTxt = ""
        var sent = 0
        for i in 0..<count {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.65) {
                mgr.send(title: title, subtitle: subtitle, body: bodyText, sound: sound)
                sent += 1
                statusTxt = "Sent \(sent) / \(count) ✓"
                if sent == count { sending = false }
            }
        }
    }
}

// MARK: - Root View

struct ContentView: View {
    @State private var tab = 0

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                tabBtn(0, "Screenshot", "camera.fill")
                tabBtn(1, "Notifications", "bell.badge.fill")
                tabBtn(2, "Terminal Runner", "exclamationmark.triangle.fill")
            }
            .padding(.horizontal, 14)
            .padding(.top, 12)
            .padding(.bottom, 8)

            Divider()

            Group {
                if tab == 0 { ScreenshotTab() }
                else if tab == 1 { NotificationsTab() }
                else if tab == 2 { TerminalErrorsTab() }
            }
            .id(tab)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(width: 480, height: 632)
        .background(Color(NSColor.windowBackgroundColor))
    }

    @ViewBuilder
    private func tabBtn(_ idx: Int, _ label: String, _ symbol: String) -> some View {
        let on = tab == idx
        
        Button { withAnimation { tab = idx } } label: {
            HStack(spacing: 6) {
                Image(systemName: symbol)
                    .font(.system(size: 12, weight: on ? .semibold : .regular))
                
                Text(label)
                    .font(.system(size: 12, weight: on ? .semibold : .regular))
                    .lineLimit(1)                 // prevents wrapping
                    .fixedSize(horizontal: true, vertical: false)
            }
            .frame(height: 30)                    // keeps all tabs identical height
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(on ? Color(NSColor.controlAccentColor).opacity(0.13) : Color.clear)
            )
            .foregroundColor(on ? Color(NSColor.controlAccentColor) : .secondary)
        }
        .buttonStyle(.borderless)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct MacAlertClone: View {
    let title: String
    let message: String
    let icon: String
    var onOK: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            // Pure Icon - No Badge Possible
            Image(nsImage: NSImage(named: icon == "stop" ? "NSStopProgressFreestanding" : (icon == "caution" ? "NSCaution" : "NSInfo")) ?? NSImage())
                .resizable()
                .frame(width: 64, height: 64)

            VStack(alignment: .leading, spacing: 10) {
                Text(title).font(.system(size: 13, weight: .bold))
                Text(message).font(.system(size: 13)).foregroundColor(.primary)
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button("OK") { onOK() }
                        .keyboardShortcut(.defaultAction)
                        .controlSize(.large)
                }
            }
        }
        .padding(25)
        .frame(width: 420, height: 160)
        .background(VisualBlurView())
    }
}

struct VisualBlurView: NSViewRepresentable {
    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        view.material = .sidebar
        view.blendingMode = .behindWindow
        view.state = .active
        return view
    }
    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {}
}

struct ScriptCreatorView: View {
    @Environment(\.presentationMode) private var presentationMode
    @State private var scriptName: String = ""
    @State private var scriptContent: String = "#!/bin/zsh\n"
    var folderURL: URL?

    var isValid: Bool {
        scriptName.count >= 3 && scriptContent.count > 15
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Create Terminal Command")
                .font(.headline)
            
            TextField("Filename (e.g. MyError.sh)", text: $scriptName)
                .textFieldStyle(.roundedBorder)

            TextEditor(text: $scriptContent)
                .font(.system(.body, design: .monospaced))
                .frame(height: 150)
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.2)))

            HStack {
                Button("Cancel") { presentationMode.wrappedValue.dismiss() }
                    .buttonStyle(.plain)
                
                Spacer()
                
                Button("Create & Run") {
                    saveAndRun()
                    presentationMode.wrappedValue.dismiss()
                }
                .disabled(!isValid)
                // Turns Green when valid, Grey when not
                .buttonStyle(FilledButton(color: isValid ? .green : .gray))
            }
        }
        .padding()
        .frame(width: 400)
    }

    private func saveAndRun() {
        guard let folder = folderURL else { return }
        let fileURL = folder.appendingPathComponent(scriptName.hasSuffix(".sh") ? scriptName : "\(scriptName).sh")
        
        do {
            // 1. Save the file
            try scriptContent.write(to: fileURL, atomically: true, encoding: .utf8)
            
            // 2. Make it executable (chmod +x)
            let chmod = Process()
            chmod.launchPath = "/bin/chmod"
            chmod.arguments = ["+x", fileURL.path]
            chmod.launch()
            chmod.waitUntilExit()
            
            // 3. Run it immediately!
            TerminalEngine.runCommand(at: fileURL)
        } catch {
            print("Error creating script: \(error)")
        }
    }
}

// MacToast Version 2.0 (pre-release)
// Copyright © 2026 Thierry Keonia
