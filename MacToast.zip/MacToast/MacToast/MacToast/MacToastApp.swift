import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// MacToastApp.swift
// Minimum: macOS 11.0 Big Sur
// Universal: arm64 (Apple Silicon) + x86_64 (Intel)
// ─────────────────────────────────────────────────────────────────────────────

@main
struct MacToastApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                // Fix window size on Big Sur — windowResizability needs macOS 13
                .fixedSize()
        }
        .commands {
            CommandGroup(replacing: .newItem) {}
        }
    }
}

